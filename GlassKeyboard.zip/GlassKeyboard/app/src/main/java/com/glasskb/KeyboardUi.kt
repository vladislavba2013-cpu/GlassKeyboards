.weight(1f)
.horizontalScroll(rememberScrollState()),
horizontalArrangement = Arrangement.spacedBy(6.dp),
verticalAlignment = Alignment.CenterVertically,
) {
ToolChip("\uD83D\uDE00", controller.panel == Panel.EMOJI, look) { controller.togglePanel(Panel.EMOJI) }
ToolChip("GIF", controller.panel == Panel.GIF, look) { controller.togglePanel(Panel.GIF) }
ToolChip("\uD83D\uDCCB", controller.panel == Panel.CLIP, look) { controller.togglePanel(Panel.CLIP) }
if (s.editPanel) {
ToolChip("⇄", controller.panel == Panel.EDIT, look) { controller.togglePanel(Panel.EDIT) }
}
ToolChip("\uD83E\uDD1A", s.oneHand != "off", look) { controller.cycleOneHand() }
ToolChip("⚙", false, look) { controller.openSettings() }
}
}
if (s.micButton) {
Box(
modifier = Modifier
.size(36.dp)
.clip(CircleShape)
.background(if (controller.listening) look.p.enter else look.p.special)
.clickable { controller.startVoice() },
contentAlignment = Alignment.Center,
) {
Text(
text = if (controller.listening) "●" else "\uD83C\uDFA4",
color = if (controller.listening) look.p.enterText else look.p.specialText,
fontSize = 15.sp,
)
}
}
}
}
@Composable
private fun GboardFourSquaresIcon(color: Color, active: Boolean) {
Canvas(Modifier.size(16.dp)) {
val gap = 2.dp.toPx()
val cell = (size.width - gap) / 2f
val r = 1.5.dp.toPx()
val popupH = 48.dp
val leftPx = (popup.keyBounds.center.x - rootBounds.left - with(density) { popupW.toPx() } / 2f)
.coerceIn(4f, (rootBounds.width - with(density) { popupW.toPx() } - 4f).coerceAtLeast(4f))
val topPx = (popup.keyBounds.top - rootBounds.top - with(density) { popupH.toPx() + 6.dp.toPx() })
.coerceAtLeast(0f)
Row(
modifier = Modifier
.offset { IntOffset(leftPx.roundToInt(), topPx.roundToInt()) }
.height(popupH)
.clip(RoundedCornerShape(14.dp))
.background(look.p.panel)
.border(1.dp, look.p.outline, RoundedCornerShape(14.dp))
.padding(horizontal = 4.dp),
verticalAlignment = Alignment.CenterVertically,
) {
items.forEachIndexed { idx, ch ->
val selected = popup.variants.isNotEmpty() && idx == popup.selectedVariantIdx
Box(
modifier = Modifier
.width(itemW)
.height(40.dp)
.clip(RoundedCornerShape(10.dp))
.background(if (selected) look.p.enter else Color.Transparent),
contentAlignment = Alignment.Center,
) {
Text(
text = ch,
color = if (selected) look.p.enterText else look.p.keyText,
fontSize = 22.sp,
fontFamily = look.fontFamily,
fontWeight = FontWeight.SemiBold,
)
}
}
}
}
```