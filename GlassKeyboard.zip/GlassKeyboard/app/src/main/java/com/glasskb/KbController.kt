package com.glasskb

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Panel { NONE, EMOJI, GIF, CLIP, EDIT }

object Suggest {
    private val ru = listOf(
        "привет", "пока", "спасибо", "пожалуйста", "хорошо", "конечно", "сейчас", "сегодня", "завтра",
        "потом", "сколько", "почему", "когда", "где", "как", "что", "давай", "можно", "нужно", "ладно",
        "извини", "отлично", "здравствуйте", "добрый", "день", "вечер", "утро", "работа", "дома", "люблю",
    )
    private val en = listOf(
        "hello", "thanks", "please", "sorry", "okay", "great", "today", "tomorrow", "later", "because",
        "what", "when", "where", "which", "would", "could", "should", "there", "their", "about", "really",
        "good", "morning", "evening", "love", "think", "know", "going", "doing", "right",
    )
    private val learned = LinkedHashMap<String, Int>()

    fun learn(word: String) {
        val w = word.lowercase()
        if (w.length < 3) return
        learned[w] = (learned[w] ?: 0) + 1
        if (learned.size > 300) learned.remove(learned.keys.first())
    }

    fun forPrefix(prefix: String, lang: String): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val fromLearned = learned.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }.map { it.key }
        val base = (if (lang == "ru") ru else en).filter { it.startsWith(p) && it != p }
        return (fromLearned + base).distinct().take(3)
    }
}

class KbController(private val service: InputMethodService) {
    var lang by mutableStateOf("ru")
    var shift by mutableIntStateOf(0)          // 0 выкл, 1 одна заглавная, 2 caps lock
    var page by mutableIntStateOf(0)           // 0 буквы, 1 ?123, 2 =\<
    var panel by mutableStateOf(Panel.NONE)
    var numericMode by mutableStateOf(false)
    var actionGlyph by mutableStateOf("↵")
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var clipPreview by mutableStateOf<String?>(null)
    var langMenu by mutableStateOf(false)
    var toolsPinned by mutableStateOf(false)
    var selecting by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var floatOffsetX by mutableFloatStateOf(0f)
    var floatOffsetY by mutableFloatStateOf(0f)

    val kbBounds = android.graphics.Rect()
    var kbTopInView = 0

    private var recognizer: SpeechRecognizer? = null
    private var clipboard: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(service)?.toString().orEmpty()
        if (text.isNotBlank()) {
            SettingsStore.addClip(text)
            clipPreview = text.take(28)
        }
    }

    fun attach() {
        clipboard = service.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.addPrimaryClipChangedListener(clipListener)
        val initial = clipboard?.primaryClip?.getItemAt(0)?.coerceToText(service)?.toString().orEmpty()
        if (initial.isNotBlank()) {
            SettingsStore.addClip(initial)
            clipPreview = initial.take(28)
        }
    }

    fun detach() {
        stopVoice()
        clipboard?.removePrimaryClipChangedListener(clipListener)
    }

    fun updateBounds(l: Int, t: Int, r: Int, b: Int) {
        if (kbBounds.left == l && kbBounds.top == t && kbBounds.right == r && kbBounds.bottom == b) return
        kbBounds.set(l, t, r, b)
        kbTopInView = t
        (service as? KeyboardService)?.refreshInsets()
    }

    fun onStartInput(info: EditorInfo?) {
        panel = Panel.NONE
        langMenu = false
        selecting = false
        val inputType = info?.inputType ?: 0
        val cls = inputType and InputType.TYPE_MASK_CLASS
        numericMode = SettingsStore.settings.numpad &&
            (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE)

        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        actionGlyph = when (action) {
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_NEXT -> "⇥"
            EditorInfo.IME_ACTION_DONE -> "✓"
            EditorInfo.IME_ACTION_GO -> "→"
            else -> "↵"
        }
        updateSuggestions()
    }

    private fun ic(): InputConnection? = service.currentInputConnection

    fun onChar(raw: String) {
        val conn = ic() ?: return
        val override = pendingVariantOverride
        pendingVariantOverride = null
        val base = override ?: raw
        val text = if (base.length == 1 && page == 0 && shift > 0) base.uppercase() else base
        conn.commitText(text, 1)
        if (shift == 1) shift = 0

        if (text == " " || text in listOf(".", ",", "!", "?", "\n")) {
            val before = conn.getTextBeforeCursor(40, 0)?.toString().orEmpty().trimEnd()
            val lastWord = before.takeLastWhile { it.isLetter() }
            if (lastWord.length >= 3) Suggest.learn(lastWord)
            suggestions = emptyList()
        } else {
            updateSuggestions()
        }
    }

    fun onBackspace() {
        val conn = ic() ?: return
        val selected = conn.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            conn.commitText("", 1)
        } else {
            conn.deleteSurroundingText(1, 0)
        }
        updateSuggestions()
    }

    fun onEnter() {
        val conn = ic() ?: return
        val info = service.currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            conn.performEditorAction(action)
        } else {
            conn.commitText("\n", 1)
        }
        suggestions = emptyList()
    }

    fun onShift() {
        shift = (shift + 1) % 3
    }

    fun toggleLang() {
        lang = if (lang == "ru") "en" else "ru"
        updateSuggestions()
    }

    fun togglePanel(target: Panel) {
        panel = if (panel == target) Panel.NONE else target
    }

    fun cycleOneHand() {
        val next = when (SettingsStore.settings.oneHand) {
            "off" -> "right"
            "right" -> "left"
            else -> "off"
        }
        SettingsStore.update { it.copy(oneHand = next) }
    }

    fun flipOneHand() {
        val cur = SettingsStore.settings.oneHand
        if (cur == "left") SettingsStore.update { it.copy(oneHand = "right") }
        else if (cur == "right") SettingsStore.update { it.copy(oneHand = "left") }
    }

    fun openSettings() {
        val intent = Intent(service, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        service.startActivity(intent)
    }

    fun showImePicker() {
        val imm = service.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showInputMethodPicker()
    }

    fun applySuggestion(word: String) {
        val conn = ic() ?: return
        val before = conn.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        val prefix = before.takeLastWhile { it.isLetter() }
        if (prefix.isNotEmpty()) {
            conn.deleteSurroundingText(prefix.length, 0)
        }
        val finalWord = if (prefix.firstOrNull()?.isUpperCase() == true) {
            word.replaceFirstChar { it.uppercase() }
        } else word
        conn.commitText("$finalWord ", 1)
        Suggest.learn(word)
        suggestions = emptyList()
    }

    private fun updateSuggestions() {
        if (!SettingsStore.settings.suggestions) {
            suggestions = emptyList()
            return
        }
        val before = ic()?.getTextBeforeCursor(40, 0)?.toString().orEmpty()
        val prefix = before.takeLastWhile { it.isLetter() }
        suggestions = Suggest.forPrefix(prefix, lang)
    }

    fun commitGif(item: GifItem) {
        GifStore.commitGif(service, ic(), service.currentInputEditorInfo, item)
    }

    fun copyToSystemClipboard(text: String) {
        clipboard?.setPrimaryClip(ClipData.newPlainText("glasskb", text))
        clipPreview = text.take(28)
    }

    fun editCommand(cmd: String) {
        val conn = ic() ?: return
        when (cmd) {
            "selectAll" -> conn.performContextMenuAction(android.R.id.selectAll)
            "copy" -> conn.performContextMenuAction(android.R.id.copy)
            "cut" -> conn.performContextMenuAction(android.R.id.cut)
            "paste" -> conn.performContextMenuAction(android.R.id.paste)
        }
    }

    fun moveCursor(dx: Int, dy: Int) {
        val conn = ic() ?: return
        val code = when {
            dx < 0 -> KeyEvent.KEYCODE_DPAD_LEFT
            dx > 0 -> KeyEvent.KEYCODE_DPAD_RIGHT
            dy < 0 -> KeyEvent.KEYCODE_DPAD_UP
            dy > 0 -> KeyEvent.KEYCODE_DPAD_DOWN
            else -> return
        }
        val meta = if (selecting) KeyEvent.META_SHIFT_ON else 0
key = Color.White,
keyText = Color(0xFF1D1B20),
special = Color(0xFFE8DEF8),
specialText = Color(0xFF1D192B),
enter = Color(0xFF6750A4),
enterText = Color.White,
shiftOn = Color(0xFF625B71),
shiftOnText = Color.White,
highlight = Color(0xFFD0BCFF),
outline = Color(0xFF79747E),
hint = Color(0xFF49454F),
panel = Color(0xFFECE6F0),
)
}
if (amoled) {
p = p.copy(bg = Color.Black, panel = Color.Black)
}
return p
}
fun applyOverrides(base: Palette, s: KbSettings): Palette {
var p = base
if (s.accent != 0) {
val acc = Color(s.accent)
p = p.copy(enter = acc, shiftOn = acc, highlight = lerp(p.key, acc, 0.35f))
}
if (s.enterColor != 0) p = p.copy(enter = Color(s.enterColor))
if (s.shiftColor != 0) p = p.copy(shiftOn = Color(s.shiftColor))
if (s.highlightColor != 0) p = p.copy(highlight = Color(s.highlightColor))
return p
}
fun resolveFontFamily(s: KbSettings, info: ThemeInfo): FontFamily {
if (s.customFontPath.isNotEmpty()) {
val file = File(s.customFontPath)
if (file.exists()) {
runCatching {
val tf = Typeface.createFromFile(file)
return FontFamily(tf)
}
}
}
val kind = info.forcedFont ?: s.fontFamily
return when (kind) {
"serif" -> FontFamily.Serif
"mono", "pixel" -> FontFamily.Monospace
"system" -> FontFamily.Default
else -> FontFamily.SansSerif
}
}
fun toCustomTheme(id: String, name: String, info: ThemeInfo, p: Palette): CustomTheme = CustomTheme(
id = id,
name = name,
style = info.style.name,
shapeable = info.shapeable,
bg = p.bg.toArgb(),
key = p.key.toArgb(),
keyText = p.keyText.toArgb(),
special = p.special.toArgb(),
specialText = p.specialText.toArgb(),
enter = p.enter.toArgb(),
enterText = p.enterText.toArgb(),
shiftOn = p.shiftOn.toArgb(),
outline = p.outline.toArgb(),
hint = p.hint.toArgb(),
)
}
@Composable
fun rememberKbLook(s: KbSettings): KbLook {
val context = LocalContext.current
val systemDark = isSystemInDarkTheme()
val customList = SettingsStore.customThemes
return remember(s, systemDark, customList) {
val isDark = Themes.resolveDark(s.mode, systemDark)
val amoled = s.mode == "amoled"
val info = Themes.builtIn.firstOrNull { it.id == s.themeId }
?: customList.firstOrNull { it.id == s.themeId }?.toInfo()
?: Themes.builtIn.first()
val rawPalette = Themes.paletteFor(context, info.id, isDark, amoled, customList)
val palette = Themes.applyOverrides(rawPalette, s)
val glass = s.liquidGlass || info.style == KeyStyle.GLASS
val ff = Themes.resolveFontFamily(s, info)
val fw = FontWeight(s.fontWeight.coerceIn(300, 800))
KbLook(
p = palette,
info = info,
s = s,
isDark = isDark,
glass = glass,
fontFamily = ff,
fontWeight = fw,
)
}
}