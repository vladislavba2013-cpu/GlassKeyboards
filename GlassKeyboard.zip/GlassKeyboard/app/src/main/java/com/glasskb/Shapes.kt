package com.glasskb

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

private const val TAU = (2.0 * PI).toFloat()
private const val SAMPLES = 240

internal fun radial(kind: String, th: Float, n: Int, d: Float): Float = when (kind) {
    "circle" -> 1f
    "square" -> {
        val p = 5.0
        val c = abs(cos(th)).toDouble().pow(p)
        val s = abs(sin(th)).toDouble().pow(p)
        (1.0 / (c + s).pow(1.0 / p)).toFloat()
    }
    "cookie" -> 1f - d * (1f - cos(n * th)) / 2f
    "sun" -> {
        val u = n * th / TAU
        val tri = abs((u - floor(u)) * 2f - 1f)
        1f - 2.2f * d * (1f - tri)
    }
    "flower" -> 1f - 2f * d * (1f - abs(cos(n * th / 2f)))
    "clover" -> {
        val depth = (d * 3.5f).coerceIn(0.16f, 0.42f)
        1f - depth * (1f - cos(4f * th)) / 2f
    }
    else -> 1f
}

private fun wideCorner(kind: String): Float = when (kind) {
    "circle" -> 0.5f
    "square" -> 0.22f
    else -> 0.38f
}

class RadialShape(
    private val from: String,
    private val to: String,
    private val t: Float,
    private val waves: Int,
    private val depth: Float,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return Outline.Rectangle(Rect(0f, 0f, w, h))
        if (w / h > 1.7f || h / w > 1.7f) {
            val c = min(w, h) * (wideCorner(from) + (wideCorner(to) - wideCorner(from)) * t)
            return Outline.Rounded(RoundRect(Rect(0f, 0f, w, h), CornerRadius(c, c)))
        }
        val cx = w / 2f
        val cy = h / 2f
        val path = Path()
        for (i in 0..SAMPLES) {
            val th = TAU * i / SAMPLES
            val a = radial(from, th, waves, depth)
            val b = radial(to, th, waves, depth)
            val r = a + (b - a) * t
            val x = cx + cx * r * cos(th)
            val y = cy + cy * r * sin(th)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

fun keyShape(look: KbLook, pressT: Float): Shape {
    val s = look.s
    if (!look.info.shapeable) {
        val corner = (look.info.forcedCorner ?: s.cornerDp).dp
        return RoundedCornerShape(corner)
    }
    val base = s.shape
    val (from, to) = when (s.morph) {
        "square_circle" -> "square" to "circle"
        "cookie_circle" -> base to "circle"
        "spring" -> base to base
        else -> base to "square" // circle_square / default
    }
    return RadialShape(
        from = from,
        to = to,
        t = pressT.coerceIn(0f, 1f),
        waves = s.waves.coerceIn(6, 20),
        depth = (s.waveDepthPct / 100f).coerceIn(0f, 0.15f),
    )
}