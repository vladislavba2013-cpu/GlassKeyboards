package com.glasskb

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class KbSettings(
    // Темы
    val mode: String = "auto",              // auto | light | dark | amoled
    val themeId: String = "m3expressive",
    val accent: Int = 0,                    // 0 = цвет темы
    val enterColor: Int = 0,
    val shiftColor: Int = 0,
    val highlightColor: Int = 0,
    val liquidGlass: Boolean = false,
    val keyMerge: Boolean = false,
    // Размеры
    val keyHeightDp: Int = 54,
    val widthPct: Int = 100,
    val landscapePct: Int = 100,
    val cornerDp: Int = 16,
    val keyGapDp: Int = 5,
    val rowGapDp: Int = 8,
    val sidePadDp: Int = 6,
    val bottomPadDp: Int = 8,
    // Режимы
    val oneHand: String = "off",            // off | left | right
    val oneHandWidthPct: Int = 70,
    val floating: Boolean = false,
    val splitLandscape: Boolean = false,
    // Клавиши и кнопки
    val numberRow: Boolean = true,
    val hints: Boolean = true,
    val popup: Boolean = true,
    val keyOutline: Boolean = false,
    val editPanel: Boolean = true,
    val toolsLongPress: String = "pin",     // pin | edit
    val langLongPress: String = "list",     // list | picker | emoji | clipboard | voice | settings | onehand | none
    val punctOnSymbols: Boolean = true,
    val emojiButton: Boolean = true,
    val leftOfSpace: String = "none",       // none | , | . | custom
    val rightOfSpace: String = "none",
    val customLeft: String = "",
    val customRight: String = "",
    val micButton: Boolean = true,
    val numpad: Boolean = true,
    val topBar: Boolean = true,
    val suggestions: Boolean = true,
    val bottomRow: String = "sym,lang,emoji,left,space,right,enter",
    val longPressMode: String = "variants", // variants | gboard
    // Шрифт
    val fontFamily: String = "rounded",     // rounded | system | serif | mono | pixel
    val fontWeight: Int = 500,
    val fontScalePct: Int = 100,
    val customFontPath: String = "",
    // Форма
    val shape: String = "cookie",           // cookie | sun | flower | clover | circle | square
    val waves: Int = 12,
    val waveDepthPct: Int = 6,
    val morph: String = "circle_square",    // circle_square | square_circle | cookie_circle | spring
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("mode", mode); put("themeId", themeId); put("accent", accent)
        put("enterColor", enterColor); put("shiftColor", shiftColor); put("highlightColor", highlightColor)
        put("liquidGlass", liquidGlass); put("keyMerge", keyMerge)
        put("keyHeightDp", keyHeightDp); put("widthPct", widthPct); put("landscapePct", landscapePct)
        put("cornerDp", cornerDp); put("keyGapDp", keyGapDp); put("rowGapDp", rowGapDp)
        put("sidePadDp", sidePadDp); put("bottomPadDp", bottomPadDp)
        put("oneHand", oneHand); put("oneHandWidthPct", oneHandWidthPct)
        put("floating", floating); put("splitLandscape", splitLandscape)
        put("numberRow", numberRow); put("hints", hints); put("popup", popup)
        put("keyOutline", keyOutline); put("editPanel", editPanel)
        put("toolsLongPress", toolsLongPress); put("langLongPress", langLongPress)
        put("punctOnSymbols", punctOnSymbols); put("emojiButton", emojiButton)
        put("leftOfSpace", leftOfSpace); put("rightOfSpace", rightOfSpace)
        put("customLeft", customLeft); put("customRight", customRight)
        put("micButton", micButton); put("numpad", numpad)
        put("topBar", topBar); put("suggestions", suggestions)
        put("bottomRow", bottomRow); put("longPressMode", longPressMode)
        put("fontFamily", fontFamily); put("fontWeight", fontWeight)
        put("fontScalePct", fontScalePct); put("customFontPath", customFontPath)
        put("shape", shape); put("waves", waves)
        put("waveDepthPct", waveDepthPct); put("morph", morph)
    }

    companion object {
        fun fromJson(j: JSONObject): KbSettings = KbSettings(
            mode = j.optString("mode", "auto"),
            themeId = j.optString("themeId", "m3expressive"),
            accent = j.optInt("accent", 0),
            enterColor = j.optInt("enterColor", 0),
            shiftColor = j.optInt("shiftColor", 0),
            highlightColor = j.optInt("highlightColor", 0),
            liquidGlass = j.optBoolean("liquidGlass", false),
            keyMerge = j.optBoolean("keyMerge", false),
            keyHeightDp = j.optInt("keyHeightDp", 54).coerceIn(40, 70),
            widthPct = j.optInt("widthPct", 100).coerceIn(70, 100),
            landscapePct = j.optInt("landscapePct", 100).coerceIn(50, 100),
            cornerDp = j.optInt("cornerDp", 16).coerceIn(0, 30),
            keyGapDp = j.optInt("keyGapDp", 5).coerceIn(0, 12),
            rowGapDp = j.optInt("rowGapDp", 8).coerceIn(0, 16),
            sidePadDp = j.optInt("sidePadDp", 6).coerceIn(0, 20),
            bottomPadDp = j.optInt("bottomPadDp", 8).coerceIn(0, 30),
            oneHand = j.optString("oneHand", "off"),
            oneHandWidthPct = j.optInt("oneHandWidthPct", 70).coerceIn(55, 85),
            floating = j.optBoolean("floating", false),
            splitLandscape = j.optBoolean("splitLandscape", false),
            numberRow = j.optBoolean("numberRow", true),
            hints = j.optBoolean("hints", true),
            popup = j.optBoolean("popup", true),
            keyOutline = j.optBoolean("keyOutline", false),
            editPanel = j.optBoolean("editPanel", true),
            toolsLongPress = j.optString("toolsLongPress", "pin"),
            langLongPress = j.optString("langLongPress", "list"),
            punctOnSymbols = j.optBoolean("punctOnSymbols", true),
            emojiButton = j.optBoolean("emojiButton", true),
            leftOfSpace = j.optString("leftOfSpace", "none"),
            rightOfSpace = j.optString("rightOfSpace", "none"),
            customLeft = j.optString("customLeft", ""),
            customRight = j.optString("customRight", ""),
            micButton = j.optBoolean("micButton", true),
            numpad = j.optBoolean("numpad", true),
            topBar = j.optBoolean("topBar", true),
            suggestions = j.optBoolean("suggestions", true),
            bottomRow = j.optString("bottomRow", "sym,lang,emoji,left,space,right,enter"),
            longPressMode = j.optString("longPressMode", "variants"),
            fontFamily = j.optString("fontFamily", "rounded"),
            fontWeight = j.optInt("fontWeight", 500).coerceIn(300, 800),
            fontScalePct = j.optInt("fontScalePct", 100).coerceIn(70, 140),
            customFontPath = j.optString("customFontPath", ""),
            shape = j.optString("shape", "cookie"),
            waves = j.optInt("waves", 12).coerceIn(6, 20),
            waveDepthPct = j.optInt("waveDepthPct", 6).coerceIn(0, 15),
            morph = j.optString("morph", "circle_square"),
        )
    }
}

object SettingsStore {
    private const val PREFS = "glasskb_prefs"
    private const val KEY_SETTINGS = "settings_json"
    private const val KEY_CUSTOM_THEMES = "custom_themes"
    private const val KEY_PINNED_CLIPS = "pinned_clips"
    private const val KEY_CLIP_HISTORY = "clip_history"

    private var prefs: SharedPreferences? = null

    var settings by mutableStateOf(KbSettings())
        private set

    var customThemes by mutableStateOf<List<CustomTheme>>(emptyList())
        private set

    var pinnedClips by mutableStateOf<List<String>>(emptyList())
        private set

    var clipHistory by mutableStateOf<List<String>>(emptyList())
        private set

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        p.getString(KEY_SETTINGS, null)?.let { raw ->
            runCatching { settings = KbSettings.fromJson(JSONObject(raw)) }
        }
        p.getString(KEY_CUSTOM_THEMES, null)?.let { raw ->
            runCatching {
                val arr = JSONArray(raw)
                customThemes = (0 until arr.length()).map { CustomTheme.fromJson(arr.getJSONObject(it)) }
            }
        }
        pinnedClips = loadStringList(p, KEY_PINNED_CLIPS)
        clipHistory = loadStringList(p, KEY_CLIP_HISTORY)
    }

    fun update(transform: (KbSettings) -> KbSettings) {
        val next = transform(settings)
        settings = next
        prefs?.edit()?.putString(KEY_SETTINGS, next.toJson().toString())?.apply()
    }

    fun saveCustomTheme(theme: CustomTheme) {
        val updated = customThemes.filterNot { it.id == theme.id } + theme
        customThemes = updated
        val arr = JSONArray().apply { updated.forEach { put(it.toJson()) } }
        prefs?.edit()?.putString(KEY_CUSTOM_THEMES, arr.toString())?.apply()
    }

    fun deleteCustomTheme(id: String) {
        val updated = customThemes.filterNot { it.id == id }
        customThemes = updated
        val arr = JSONArray().apply { updated.forEach { put(it.toJson()) } }
        prefs?.edit()?.putString(KEY_CUSTOM_THEMES, arr.toString())?.apply()
        if (settings.themeId == id) update { it.copy(themeId = "m3expressive") }
    }

    fun addClip(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val next = (listOf(clean) + clipHistory.filterNot { it == clean }).take(25)
        clipHistory = next
        saveStringList(KEY_CLIP_HISTORY, next)
    }

    fun togglePinClip(text: String) {
        val next = if (text in pinnedClips) pinnedClips - text else (listOf(text) + pinnedClips).take(15)
        pinnedClips = next
        saveStringList(KEY_PINNED_CLIPS, next)
    }

    fun removeClip(text: String) {
        clipHistory = clipHistory - text
pinnedClips = pinnedClips - text
```kotlin
    fun removeClip(text: String) {
        clipHistory = clipHistory - text
        pinnedClips = pinnedClips - text
        saveStringList(KEY_CLIP_HISTORY, clipHistory)
        saveStringList(KEY_PINNED_CLIPS, pinnedClips)
    }

    private fun loadStringList(p: SharedPreferences, key: String): List<String> {
        val raw = p.getString(key, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrDefault(emptyList())
    }

    private fun saveStringList(key: String, list: List<String>) {
        val arr = JSONArray().apply { list.forEach { put(it) } }
        prefs?.edit()?.putString(key, arr.toString())?.apply()
    }
}