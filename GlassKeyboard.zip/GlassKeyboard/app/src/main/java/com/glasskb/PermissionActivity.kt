package com.glasskb

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle

/** Прозрачная активность: сервис клавиатуры не может сам показать системный диалог разрешения. */
class PermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            finishWith(true)
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        finishWith(grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
    }

    private fun finishWith(granted: Boolean) {
        val cb = onResult
        onResult = null
        finish()
        cb?.invoke(granted)
    }

    companion object {
        var onResult: ((Boolean) -> Unit)? = null
    }
}
