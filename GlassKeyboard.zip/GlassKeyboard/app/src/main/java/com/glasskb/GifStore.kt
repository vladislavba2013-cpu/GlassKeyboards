package com.glasskb

import android.content.ClipDescription
import android.content.Context
import android.net.Uri
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import androidx.core.content.FileProvider
import java.io.File

data class GifItem(
    val id: String,
    val title: String,
    val tag: String,
    val colorHex: Long,
    val emoji: String,
)

object GifStore {
    val builtInGifs = listOf(
        GifItem("gif_hi", "Привет!", "Привет", 0xFF6366F1, "👋"),
        GifItem("gif_lol", "Смешно до слёз", "Смех", 0xFFF59E0B, "😂"),
        GifItem("gif_love", "Люблю тебя", "Любовь", 0xFFEC4899, "❤️"),
        GifItem("gif_ok", "Окей, принято", "Ок", 0xFF10B981, "👌"),
        GifItem("gif_fire", "Огонь!", "Огонь", 0xFFEF4444, "🔥"),
        GifItem("gif_sad", "Грустно", "Грусть", 0xFF3B82F6, "😢"),
        GifItem("gif_party", "Праздник!", "Веселье", 0xFF8B5CF6, "🎉"),
        GifItem("gif_facepalm", "Рукалицо", "Фейспалм", 0xFF64748B, "🤦"),
        GifItem("gif_cat", "Котик одобряет", "Котики", 0xFFF97316, "🐱"),
        GifItem("gif_wow", "Вау, шок!", "Шок", 0xFF06B6D4, "🤯"),
        GifItem("gif_coffee", "Пора пить кофе", "Кофе", 0xFF78350F, "☕"),
        GifItem("gif_sleep", "Спокойной ночи", "Сон", 0xFF1E3A8A, "😴"),
    )

    fun search(query: String): List<GifItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return builtInGifs
        return builtInGifs.filter {
            it.title.lowercase().contains(q) || it.tag.lowercase().contains(q)
        }
    }

    fun commitGif(context: Context, ic: InputConnection?, editorInfo: EditorInfo?, item: GifItem): Boolean {
        if (ic == null) return false
        val mimeTypes = editorInfo?.contentMimeTypes ?: emptyArray()
        val supportsGif = mimeTypes.any { ClipDescription.compareMimeTypes(it, "image/gif") || ClipDescription.compareMimeTypes(it, "image/*") }
        if (supportsGif) {
            runCatching {
                val dir = File(context.cacheDir, "gifs").apply { mkdirs() }
                val file = File(dir, "${item.id}.gif")
                if (!file.exists()) {
                    file.writeBytes(minimalGifBytes())
                }
                val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val info = InputContentInfo(uri, ClipDescription(item.title, arrayOf("image/gif")), null)
                if (ic.commitContent(info, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) {
                    return true
                }
            }
        }
        ic.commitText("${item.emoji} [${item.title}] ", 1)
        return true
    }

    private fun minimalGifBytes(): ByteArray = byteArrayOf(
        0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00, 0x01, 0x00,
        0x80.toByte(), 0x00, 0x00, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(),
        0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00,
        0x01, 0x00, 0x00, 0x02, 0x02, 0x44, 0x01, 0x00, 0x3B
    )
}
