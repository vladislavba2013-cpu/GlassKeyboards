package com.glasskb

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SettingsStore.init(this)
        setContent {
            val s = SettingsStore.settings
            val dark = Themes.resolveDark(s.mode, isSystemInDarkTheme())
            val scheme = Themes.m3Scheme(this, dark)
            MaterialTheme(colorScheme = scheme) {
                SettingsApp()
            }
        }
    }
}

private fun isImeEnabled(context: Context): Boolean {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
    return imm.enabledInputMethodList.any { it.packageName == context.packageName }
}

private fun isImeSelected(context: Context): Boolean {
    val current = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD).orEmpty()
    val expected = ComponentName(context, KeyboardService::class.java).flattenToShortString()
    val expectedFull = ComponentName(context, KeyboardService::class.java).flattenToString()
    return current == expected || current == expectedFull || current.startsWith(context.packageName + "/")
}

@Composable
private fun SettingsApp() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var testText by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(isImeEnabled(context)) }
    var selected by remember { mutableStateOf(isImeSelected(context)) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                enabled = isImeEnabled(context)
                selected = isImeSelected(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Glass Keyboard",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    if (!enabled || !selected) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!enabled) {
                                Button(
                                    onClick = { context.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                ) {
                                    Text("1. Включить", fontSize = 12.sp)
                                }
                            }
                            if (enabled && !selected) {
                                Button(
                                    onClick = {
                                        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                                        imm?.showInputMethodPicker()
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                ) {
                                    Text("2. Выбрать", fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "✓ Активна",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = testText,
                    onValueChange = { testText = it },
                    placeholder = { Text("Проверьте клавиатуру здесь...") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("🎨", fontSize = 18.sp) },
                    label = { Text("Темы") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("⌨️", fontSize = 18.sp) },
                    label = { Text("Клавиши и шрифт") },
                )
            }
        },
    ) { inner ->
        if (tab == 0) {
            ThemesTab(Modifier.padding(inner))
        } else {
            KeysAndFontTab(Modifier.padding(inner))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ThemesTab(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val s = SettingsStore.settings
    val look = rememberKbLook(s)
    var editingTheme by remember { mutableStateOf<CustomTheme?>(null) }
    var exportJsonTarget by remember { mutableStateOf<CustomTheme?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val ct = CustomTheme.fromJson(JSONObject(raw)).copy(id = "custom_" + System.currentTimeMillis())
                SettingsStore.saveCustomTheme(ct)
                SettingsStore.update { it.copy(themeId = ct.id) }
                Toast.makeText(context, "Тема «${ct.name}» импортирована", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "Ошибка чтения JSON темы", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        val target = exportJsonTarget
        if (uri != null && target != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(target.toJson().toString(2).toByteArray())
                }
                Toast.makeText(context, "Тема сохранена в JSON", Toast.LENGTH_SHORT).show()
            }
        }
        exportJsonTarget = null
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Режим оформления") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "auto" to "Авто",
                        "light" to "Светлая",
                        "dark" to "Тёмная",
                        "amoled" to "AMOLED",
                    ).forEach { (id, title) ->
                        FilterChip(
                            selected = s.mode == id,
                            onClick = { SettingsStore.update { it.copy(mode = id) } },
                            label = { Text(title) },
                        )
                    }
                }
            }
        }

        item {
            SectionCard("Темы клавиатуры") {
                val allThemes = Themes.builtIn + SettingsStore.customThemes.map { it.toInfo() }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    allThemes.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            pair.forEach { info ->
                                ThemePreviewCard(
                                    info = info,
                                    selected = s.themeId == info.id,
                                    modifier = Modifier.weight(1f),
                                    onSelect = { SettingsStore.update { it.copy(themeId = info.id) } },
                                    onDelete = if (!info.builtIn) {
                                        { SettingsStore.deleteCustomTheme(info.id) }
                                    } else null,
                                )
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            SectionCard("Акцентный цвет и цвета клавиш") {
                ColorRow("Акцентный цвет", s.accent) { c -> SettingsStore.update { it.copy(accent = c) } }
                ColorRow("Цвет клавиши Enter", s.enterColor) { c -> SettingsStore.update { it.copy(enterColor = c) } }
                ColorRow("Цвет Shift", s.shiftColor) { c -> SettingsStore.update { it.copy(shiftColor = c) } }
                ColorRow("Цвет подсветки нажатия", s.highlightColor) { c -> SettingsStore.update { it.copy(highlightColor = c) } }
            }
        }

        item {
            SectionCard("Эффекты") {
                ToggleRow(
                    title = "Жидкое стекло на любой теме",
                    subtitle = "Полупрозрачные клавиши, градиент и блики",
                    checked = s.liquidGlass,
                    onCheckedChange = { v -> SettingsStore.update { it.copy(liquidGlass = v) } },
                )
                ToggleRow(
                    title = "Слияние клавиш",
                    subtitle = "Метаболл-подсветка при нажатии",
                    checked = s.keyMerge,
                    onCheckedChange = { v -> SettingsStore.update { it.copy(keyMerge = v) } },
                )
            }
        }

        item {
            SectionCard("Конструктор тем") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            editingTheme = Themes.toCustomTheme(
                                id = "custom_" + System.currentTimeMillis(),
                                name = "${look.info.name} (копия)",
                                info = look.info,
                                p = look.p,
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Создать тему на основе текущей")
                    }
                    OutlinedButton(
                        onClick = {
                            editingTheme = CustomTheme.fromJson(JSONObject())
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Создать тему с нуля")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { importLauncher.launch("application/json") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Импорт (.json)")
                        }
                        OutlinedButton(
                            onClick = {
                                val currentAsCustom = Themes.toCustomTheme(
                                    id = look.info.id,
                                    name = look.info.name,
                                    info = look.info,
                                    p = look.p,
                                )
                                exportJsonTarget = currentAsCustom
                                exportLauncher.launch("${look.info.id}.json")
                            },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Экспорт (.json)")
                        }
                    }
                }
            }
        }
    }

    val draft = editingTheme
    if (draft != null) {
        CustomThemeDialog(
            initial = draft,
            onDismiss = { editingTheme = null },
            onSave = { saved ->
                SettingsStore.saveCustomTheme(saved)
                SettingsStore.update { it.copy(themeId = saved.id) }
                editingTheme = null
            },
        )
    }
}

@Composable
private fun ThemePreviewCard(
    info: ThemeInfo,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onSelect: () -> Unit,
    onDelete: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val s = SettingsStore.settings
    val dark = Themes.resolveDark(s.mode, isSystemInDarkTheme())
    val palette = remember(info.id, dark, s.mode, SettingsStore.customThemes) {
        Themes.paletteFor(context, info.id, dark, s.mode == "amoled", SettingsStore.customThemes)
    }
    val previewLook = remember(palette, info, s, dark) {
        KbLook(
            p = palette,
            info = info,
            s = s,
            isDark = dark,
            glass = info.style == KeyStyle.GLASS,
            fontFamily = Themes.resolveFontFamily(s, info),
            fontWeight = FontWeight.Medium,
        )
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.bg)
            .border(
                width = if (selected) 2.5.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else palette.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(18.dp),
            )
            .clickable { onSelect() }
            .padding(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(34.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            listOf(Role.NORMAL, Role.SPECIAL, Role.ENTER).forEachIndexed { idx, r ->
                Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawKeyBody(previewLook, r, size.width, size.height, 0f, seed = idx + 1)
                    }
                    Text(
                        text = listOf("А", "?123", "↵")[idx],
                        color = roleText(previewLook, r),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = info.name,
                color = palette.keyText,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (onDelete != null) {
                Text(
                    text = "✕",
                    color = palette.hint,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { onDelete() }.padding(start = 4.dp),
                )
            }
        }
    }
}

private val presetSwatches = listOf(
    0 to "Тема",
    0xFF6750A4.toInt() to "Фиол.",
    0xFF1A73E8.toInt() to "Синий",
    0xFF00BFA5.toInt() to "Мята",
    0xFF10B981.toInt() to "Зелён.",
    0xFFF59E0B.toInt() to "Янтарь",
    0xFFEF4444.toInt() to "Красный",
    0xFFEC4899.toInt() to "Розов.",
)

@Composable
private fun ColorRow(title: String, current: Int, onPick: (Int) -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            presetSwatches.forEach { (argb, _) ->
                val isSel = current == argb
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (argb == 0) MaterialTheme.colorScheme.surfaceVariant else Color(argb))
                        .border(if (isSel) 2.5.dp else 1.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                        .clickable { onPick(argb) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (argb == 0) Text("↺", fontSize = 13.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CustomThemeDialog(initial: CustomTheme, onDismiss: () -> Unit, onSave: (CustomTheme) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var style by remember { mutableStateOf(initial.style) }
    var shapeable by remember { mutableStateOf(initial.shapeable) }
    var bg by remember { mutableIntStateOf(initial.bg) }
    var key by remember { mutableIntStateOf(initial.key) }
    var keyText by remember { mutableIntStateOf(initial.keyText) }
    var enter by remember { mutableIntStateOf(initial.enter) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Конструктор темы") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название темы") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Стиль отрисовки", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    KeyStyle.entries.forEach { st ->
                        FilterChip(
                            selected = style == st.name,
                            onClick = { style = st.name },
                            label = { Text(st.name, fontSize = 11.sp) },
                        )
                    }
                }
                ToggleRow("Фигурные клавиши (Печенька/Солнце)", null, shapeable) { shapeable = it }
                ColorRow("Фон клавиатуры", bg) { if (it != 0) bg = it }
                ColorRow("Цвет клавиш", key) { if (it != 0) key = it }
                ColorRow("Цвет текста", keyText) { if (it != 0) keyText = it }
                ColorRow("Цвет Enter / Акцент", enter) { if (it != 0) enter = it }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    initial.copy(
                        name = name.ifBlank { "Моя тема" },
                        style = style,
                        shapeable = shapeable,
                        bg = bg,
                        key = key,
                        keyText = keyText,
                        enter = enter,
                        shiftOn = enter,
                    )
                )
            }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KeysAndFontTab(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val s = SettingsStore.settings

    val fontLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val dest = File(context.filesDir, "custom_font.ttf")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                SettingsStore.update { it.copy(customFontPath = dest.absolutePath) }
                Toast.makeText(context, "Шрифт загружен", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "Не удалось загрузить файл шрифта", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Размеры") {
                SliderRow("Высота клавиш", s.keyHeightDp, 40..70, "dp") { v -> SettingsStore.update { it.copy(keyHeightDp = v) } }
                SliderRow("Ширина клавиатуры", s.widthPct, 70..100, "%") { v -> SettingsStore.update { it.copy(widthPct = v) } }
                SliderRow("Размер в альбомной ориентации", s.landscapePct, 50..100, "%") { v -> SettingsStore.update { it.copy(landscapePct = v) } }
                SliderRow("Скругление клавиш", s.cornerDp, 0..30, "dp") { v -> SettingsStore.update { it.copy(cornerDp = v) } }
                SliderRow("Промежуток между клавишами", s.keyGapDp, 0..12, "dp") { v -> SettingsStore.update { it.copy(keyGapDp = v) } }
                SliderRow("Промежуток между рядами", s.rowGapDp, 0..16, "dp") { v -> SettingsStore.update { it.copy(rowGapDp = v) } }
                SliderRow("Отступы по бокам", s.sidePadDp, 0..20, "dp") { v -> SettingsStore.update { it.copy(sidePadDp = v) } }
                SliderRow("Отступ снизу", s.bottomPadDp, 0..30, "dp") { v -> SettingsStore.update { it.copy(bottomPadDp = v) } }
            }
        }

        item {
            SectionCard("Режим одной руки и раскладка") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("off" to "Выкл", "left" to "Слева", "right" to "Справа").forEach { (id, title) ->
                            FilterChip(
                                selected = s.oneHand == id,
                                onClick = { SettingsStore.update { it.copy(oneHand = id) } },
                                label = { Text(title) },
                            )
                        }
                    }
                    if (s.oneHand != "off") {
                        OutlinedButton(onClick = {
                            val flipped = if (s.oneHand == "left") "right" else "left"
                            SettingsStore.update { it.copy(oneHand = flipped) }
                        }) { Text("⇄") }
                    }
                }
                if (s.oneHand != "off") {
                    SliderRow("Ширина одной рукой", s.oneHandWidthPct, 55..85, "%") { v ->
                        SettingsStore.update { it.copy(oneHandWidthPct = v) }
                    }
                }
                ToggleRow("Плавающая клавиатура", "Перетаскивание за верхнюю полоску", s.floating) { v ->
                    SettingsStore.update { it.copy(floating = v) }
                }
                ToggleRow("Раздельная в альбомной ориентации", null, s.splitLandscape) { v ->
                    SettingsStore.update { it.copy(splitLandscape = v) }
                }
            }
        }

        item {
            SectionCard("Клавиши и кнопки") {
                ToggleRow("Ряд цифр", null, s.numberRow) { v -> SettingsStore.update { it.copy(numberRow = v) } }
                ToggleRow("Подсказки на клавишах", null, s.hints) { v -> SettingsStore.update { it.copy(hints = v) } }
                ToggleRow("Всплывающая буква при нажатии", null, s.popup) { v -> SettingsStore.update { it.copy(popup = v) } }
                ToggleRow("Контур клавиш", null, s.keyOutline) { v -> SettingsStore.update { it.copy(keyOutline = v) } }
                ToggleRow("Панель редактирования", null, s.editPanel) { v -> SettingsStore.update { it.copy(editPanel = v) } }
                ToggleRow("Запятая и точка на ?123", null, s.punctOnSymbols) { v -> SettingsStore.update { it.copy(punctOnSymbols = v) } }
                ToggleRow("Кнопка эмодзи", null, s.emojiButton) { v -> SettingsStore.update { it.copy(emojiButton = v) } }
                ToggleRow("Кнопка микрофона", null, s.micButton) { v -> SettingsStore.update { it.copy(micButton = v) } }
                ToggleRow("Цифровая клавиатура 4x4", "Для числовых полей ввода", s.numpad) { v -> SettingsStore.update { it.copy(numpad = v) } }
                ToggleRow("Верхняя панель", null, s.topBar) { v -> SettingsStore.update { it.copy(topBar = v) } }
                ToggleRow("Строка подсказок", "Если выкл — всегда видны инструменты", s.suggestions) { v -> SettingsStore.update { it.copy(suggestions = v) } }

                Spacer(Modifier.height(6.dp))
                Text("Удержание буквы", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = s.longPressMode == "variants",
                        onClick = { SettingsStore.update { it.copy(longPressMode = "variants") } },
                        label = { Text("Варианты (ё, ъ)") },
                    )
                    FilterChip(
                        selected = s.longPressMode == "gboard",
                        onClick = { SettingsStore.update { it.copy(longPressMode = "gboard") } },
                        label = { Text("Как в Gboard (1–0)") },
                    )
                }

                Spacer(Modifier.height(6.dp))
                Text("Удержание кнопки панели функций", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = s.toolsLongPress == "pin",
                        onClick = { SettingsStore.update { it.copy(toolsLongPress = "pin") } },
                        label = { Text("Закрепить панель") },
                    )
                    FilterChip(
                        selected = s.toolsLongPress == "edit",
                        onClick = { SettingsStore.update { it.copy(toolsLongPress = "edit") } },
                        label = { Text("Панель редактирования") },
                    )
                }

                Spacer(Modifier.height(6.dp))
                Text("Удержание кнопки языка", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "list" to "Список языков",
                        "picker" to "Выбор клавиатуры",
                        "emoji" to "Эмодзи",
                        "clipboard" to "Буфер обмена",
                        "voice" to "Голосовой ввод",
                        "settings" to "Настройки",
                        "onehand" to "Одной рукой",
                        "none" to "Ничего",
                    ).forEach { (id, title) ->
                        FilterChip(
                            selected = s.langLongPress == id,
                            onClick = { SettingsStore.update { it.copy(langLongPress = id) } },
                            label = { Text(title, fontSize = 11.sp) },
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                SpaceSidePicker(
                    title = "Клавиша слева от пробела",
                    current = s.leftOfSpace,
                    customVal = s.customLeft,
                    onModeChange = { m -> SettingsStore.update { it.copy(leftOfSpace = m) } },
                    onCustomChange = { c -> SettingsStore.update { it.copy(customLeft = c) } },
                )
                SpaceSidePicker(
                    title = "Клавиша справа от пробела",
                    current = s.rightOfSpace,
                    customVal = s.customRight,
                    onModeChange = { m -> SettingsStore.update { it.copy(rightOfSpace = m) } },
                    onCustomChange = { c -> SettingsStore.update { it.copy(customRight = c) } },
                )

                Spacer(Modifier.height(8.dp))
                BottomRowOrderEditor(s.bottomRow) { next -> SettingsStore.update { it.copy(bottomRow = next) } }
            }
        }

        item {
            SectionCard("Шрифт") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "rounded" to "Округлый",
                        "system" to "Системный",
                        "serif" to "Serif",
                        "mono" to "Mono",
                        "pixel" to "Пиксели",
                    ).forEach { (id, title) ->
                        FilterChip(
                            selected = s.fontFamily == id && s.customFontPath.isEmpty(),
                            onClick = { SettingsStore.update { it.copy(fontFamily = id, customFontPath = "") } },
                            label = { Text(title) },
                        )
                    }
                }
                SliderRow("Толщина букв", s.fontWeight, 300..800, "") { v -> SettingsStore.update { it.copy(fontWeight = v) } }
                SliderRow("Размер букв", s.fontScalePct, 70..140, "%") { v -> SettingsStore.update { it.copy(fontScalePct = v) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { fontLauncher.launch("*/*") },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(if (s.customFontPath.isEmpty()) "Загрузить свой шрифт (.ttf)" else "Заменить шрифт (.ttf)")
                    }
                    if (s.customFontPath.isNotEmpty()) {
                        TextButton(onClick = { SettingsStore.update { it.copy(customFontPath = "") } }) {
                            Text("Сброс")
                        }
                    }
                }
            }
        }

        item {
            SectionCard("Форма кнопок и морфинг-анимации") {
                Text("Форма кнопок (для фигурных тем)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "cookie" to "Печенька",
                        "sun" to "Солнце",
                        "flower" to "Цветок",
                        "clover" to "Клевер",
                        "circle" to "Круг",
                        "square" to "Квадрат",
                    ).forEach { (id, title) ->
                        FilterChip(
                            selected = s.shape == id,
                            onClick = { SettingsStore.update { it.copy(shape = id) } },
                            label = { Text(title) },
                        )
                    }
                }
                SliderRow("Количество волн", s.waves, 6..20, "") { v -> SettingsStore.update { it.copy(waves = v) } }
                SliderRow("Глубина волн", s.waveDepthPct, 0..15, "%") { v -> SettingsStore.update { it.copy(waveDepthPct = v) } }

                Spacer(Modifier.height(6.dp))
                Text("Морфинг-анимация нажатия", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "circle_square" to "Круг → Квадрат",
                        "square_circle" to "Квадрат → Круг",
                        "cookie_circle" to "Печенька → Круг",
                        "spring" to "Пружина",
                    ).forEach { (id, title) ->
                        FilterChip(
                            selected = s.morph == id,
                            onClick = { SettingsStore.update { it.copy(morph = id) } },
                            label = { Text(title) },
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpaceSidePicker(
    title: String,
    current: String,
    customVal: String,
    onModeChange: (String) -> Unit,
    onCustomChange: (String) -> Unit,
) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("none" to "Нет", "," to ",", "." to ".", "custom" to "Своя...").forEach { (id, label) ->
                FilterChip(
                    selected = current == id,
                    onClick = { onModeChange(id) },
                    label = { Text(label) },
                )
            }
        }
        if (current == "custom") {
            OutlinedTextField(
                value = customVal,
                onValueChange = { onCustomChange(it.take(3)) },
                label = { Text("Символ (1–3 знака)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun BottomRowOrderEditor(rawOrder: String, onSave: (String) -> Unit) {
    val items = remember(rawOrder) {
        rawOrder.split(",").map { it.trim() }.filter { it in Layouts.bottomRowIds }
            .ifEmpty { Layouts.bottomRowIds }
    }
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Свои места клавиш (нижний ряд)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { onSave(Layouts.bottomRowIds.joinToString(",")) }) {
                Text("Сброс", fontSize = 12.sp)
            }
        }
        items.forEachIndexed { idx, id ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(Layouts.bottomRowTitle(id), fontSize = 13.sp)
                Row {
                    TextButton(
                        enabled = idx > 0,
                        onClick = {
                            val list = items.toMutableList()
                            val tmp = list[idx - 1]
                            list[idx - 1] = list[idx]
                            list[idx] = tmp
                            onSave(list.joinToString(","))
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp),
                    ) { Text("↑") }
                    TextButton(
                        enabled = idx < items.lastIndex,
                        onClick = {
                            val list = items.toMutableList()
                            val tmp = list[idx + 1]
                            list[idx + 1] = list[idx]
                            list[idx] = tmp
                            onSave(list.joinToString(","))
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp),
                    ) { Text("↓") }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, suffix: String, onChange: (Int) -> Unit) {
    Column(Modifier.padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp)
            Text("$value$suffix", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt().coerceIn(range)) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
        )
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (!subtitle.isNullOrEmpty()) {
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
