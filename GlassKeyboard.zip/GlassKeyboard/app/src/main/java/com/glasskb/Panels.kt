package com.glasskb

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class EmojiCat(val icon: String, val title: String, val items: List<String>)

private val emojiCategories = listOf(
    EmojiCat("😀", "Смайлы", listOf(
        "😀","😃","😄","😁","😆","😅","🤣","😂","🙂","🙃","😉","😊","😇","🥰","😍","🤩","😘","😗","😚","😙",
        "🥲","😋","😛","😜","🤪","😝","🤑","🤗","🤭","🤫","🤔","🤐","🤨","😐","😑","😶","😏","😒","🙄","😬",
        "🤥","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤢","🤮","🤧","🥵","🥶","🥴","😵","🤯","🤠","🥳","😎",
        "🤓","🧐","😕","😟","🙁","☹️","😮","😯","😲","😳","🥺","😦","😧","😨","😰","😥","😢","😭","😱","😖",
        "😣","😞","😓","😩","😫","🥱","😤","😡","😠","🤬","😈","👿","💀","☠️","💩","🤡","👹","👺","👻","👽"
    )),
    EmojiCat("👋", "Жесты", listOf(
        "👋","🤚","🖐️","✋","🖖","👌","🤌","🤏","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","👍",
        "👎","✊","👊","🤛","🤜","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦾","🦵","🦶","👂","🦻",
        "👃","🧠","🫀","🫁","🦷","🦴","👀","👁️","👅","👄","👶","🧒","👦","👧","🧑","👱","👨","🧔","👩","🧓"
    )),
    EmojiCat("❤️", "Сердца", listOf(
        "❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","☮️",
        "✝️","☪️","🕉️","☸️","✡️","🔯","🕎","☯️","☦️","🛐","⛎","♈","♉","♊","♋","♌","♍","♎","♏","♐",
        "♑","♒","♓","🆔","⚛️","🉑","☢️","☣️","📴","📳","🈶","🈚","🈸","🈺","🈷️","✴️","🆚","💮","🉐","㊙️"
    )),
    EmojiCat("🐱", "Животные", listOf(
        "🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐻‍❄️","🐨","🐯","🦁","🐮","🐷","🐽","🐸","🐵","🙈","🙉","🙊",
        "🐒","🐔","🐧","🐦","🐤","🐣","🐥","🦆","🦅","🦉","🦇","🐺","🐗","🐴","🦄","🐝","🪱","🐛","🦋","🐌",
        "🐞","🐜","🪰","🪲","🪳","🦟","🦗","🕷️","🕸️","🦂","🐢","🐍","🦎","🦖","🦕","🐙","🦑","🦐","🦞","🦀"
    )),
    EmojiCat("🍕", "Еда", listOf(
        "🍏","🍎","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝","🍅","🍆","🥑",
        "🥦","🥬","🥒","🌶️","🫑","🌽","🥕","🫒","🧄","🧅","🥔","🍠","🥐","🥯","🍞","🥖","🥨","🧀","🥚","🍳",
        "🧈","🥞","🧇","🥓","🥩","🍗","🍖","🌭","🍔","🍟","🍕","🫓","🥪","🥙","🧆","🌮","🌯","🫔","🥗","🥘",
        "☕","🍵","🧃","🥤","🧋","🍶","🍺","🍻","🥂","🍷","🥃","🍸","🍹","🧉","🍾","🧊","🍰","🎂","🧁","🍫"
    )),
    EmojiCat("⚽", "Спорт", listOf(
        "⚽","🏀","🏈","⚾","🥎","🎾","🏐","🏉","🥏","🎱","🪀","🏓","🏸","🏒","🏑","🥍","🏏","🪃","🥅","⛳",
        "🪁","🏹","🎣","🤿","🥊","🥋","🎽","🛹","🛼","🛷","⛸️","🥌","🎿","⛷️","🏂","🪂","🏋️","🤼","🤸","⛹️"
    )),
    EmojiCat("🚀", "Места", listOf(
        "🚗","🚕","🚙","🚌","🚎","🏎️","🚓","🚑","🚒","🚐","🛻","🚚","🚛","🚜","🏍️","🛵","🚲","🛴","🚨","🚔",
        "✈️","🛫","🛬","🚀","🛸","🚁","🛶","⛵","🚤","🛥️","🛳️","⛴️","🚢","⚓","⛽","🚧","🚦","🚥","🗺️","🗿",
        "🗽","🗼","🏰","🏯","🏟️","🎡","🎢","🎠","⛲","⛱️","🏖️","🏝️","🏜️","🌋","⛰️","🏔️","🗻","🏕️","🏠","🏡"
    )),
)

@Composable
fun ActivePanelHost(controller: KbController, look: KbLook, height: Dp) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .background(look.p.panel)
            .padding(horizontal = 6.dp, vertical = 4.dp),
    ) {
        when (controller.panel) {
            Panel.EMOJI -> EmojiPanel(controller, look)
            Panel.GIF -> GifPanel(controller, look)
            Panel.CLIP -> ClipboardPanel(controller, look)
            Panel.EDIT -> EditPanel(controller, look)
            Panel.NONE -> Unit
        }
    }
}

@Composable
private fun EmojiPanel(controller: KbController, look: KbLook) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(40.dp),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(emojiCategories[tab].items) { em ->
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { controller.onChar(em) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(em, fontSize = 24.sp)
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().height(38.dp).padding(top = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            PanelChip("ABC", look) { controller.panel = Panel.NONE }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                emojiCategories.forEachIndexed { idx, cat ->
                    val selected = idx == tab
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) look.p.highlight.copy(alpha = 0.45f) else Color.Transparent)
                            .clickable { tab = idx },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(cat.icon, fontSize = 18.sp)
                    }
                }
            }
            PanelChip("⌫", look) { controller.onBackspace() }
        }
    }
}

@Composable
private fun GifPanel(controller: KbController, look: KbLook) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) { GifStore.search(query) }
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(38.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            PanelChip("←", look) { controller.panel = Panel.NONE }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(look.p.key)
                    .border(1.dp, look.p.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (query.isEmpty()) {
                    Text("Поиск GIF (привет, смех, кот...)", color = look.p.hint, fontSize = 13.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = look.p.keyText, fontSize = 13.sp),
                    cursorBrush = SolidColor(look.p.enter),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                PanelChip("✕", look) { query = "" }
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(results, key = { it.id }) { item ->
                Box(
                    modifier = Modifier
                        .height(68.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(item.colorHex).copy(alpha = 0.85f))
                        .clickable { controller.commitGif(item) }
                        .padding(6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(item.emoji, fontSize = 22.sp)
look: KbLook) {
Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
Row(
modifier = Modifier.fillMaxWidth(),
horizontalArrangement = Arrangement.SpaceBetween,
verticalAlignment = Alignment.CenterVertically,
) {
PanelChip("← Клавиатура", look) { controller.panel = Panel.NONE }
Text("Редактирование текста", color = look.p.keyText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
PanelChip("⌫", look) { controller.onBackspace() }
}
Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
EditActionBtn("Выделить всё", look, Modifier.weight(1f)) { controller.editCommand("selectAll") }
EditActionBtn("↑", look, Modifier.weight(1f)) { controller.moveCursor(0, -1) }
EditActionBtn(
if (controller.selecting) "Выделение: ВКЛ" else "Выделение",
look,
Modifier.weight(1f),
active = controller.selecting,
) { controller.selecting = !controller.selecting }
}
Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
EditActionBtn("←", look, Modifier.weight(1f)) { controller.moveCursor(-1, 0) }
EditActionBtn("↓", look, Modifier.weight(1f)) { controller.moveCursor(0, 1) }
EditActionBtn("→", look, Modifier.weight(1f)) { controller.moveCursor(1, 0) }
}
Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
EditActionBtn("Копировать", look, Modifier.weight(1f)) { controller.editCommand("copy") }
EditActionBtn("Вырезать", look, Modifier.weight(1f)) { controller.editCommand("cut") }
EditActionBtn("Вставить", look, Modifier.weight(1f)) { controller.editCommand("paste") }
}
}
}
@Composable
private fun EditActionBtn(label: String, look: KbLook, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
Box(
modifier = modifier
.fillMaxSize()
.clip(RoundedCornerShape(12.dp))
.background(if (active) look.p.enter else look.p.key)
.clickable { onClick() }
.padding(4.dp),
contentAlignment = Alignment.Center,
) {
Text(
text = label,
color = if (active) look.p.enterText else look.p.keyText,
fontSize = 13.sp,
fontWeight = FontWeight.Medium,
textAlign = TextAlign.Center,
)
}
}
@Composable
private fun PanelChip(text: String, look: KbLook, onClick: () -> Unit) {
Box(
modifier = Modifier
.clip(RoundedCornerShape(10.dp))
.background(look.p.special)
.clickable { onClick() }
.padding(horizontal = 10.dp, vertical = 6.dp),
contentAlignment = Alignment.Center,
) {
Text(text, color = look.p.specialText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
}
}